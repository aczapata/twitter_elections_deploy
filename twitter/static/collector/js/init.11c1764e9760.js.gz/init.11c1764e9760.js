(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.parallax').parallax();
    $('.scrollspy').scrollSpy();
    $('select').material_select();
  }); // end of document ready
})(jQuery); // end of jQuery name space